<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-9 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-file-alt fa-lg text-danger"></i> LISTADO CARTA PORTE</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('cartaPorte.index')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('cartaPorte.store')); ?>" method="post" id="formularioCartaPorte">
                    <?php echo e(csrf_field()); ?>

                    <?php if(empty($id->id)): ?>
                        <input type="hidden" value="1" name="id">
                    <?php else: ?>
                        <input type="hidden" value="<?php echo e($id->id+1); ?>" name="id">
                    <?php endif; ?>
                    <div class="form-group">
                    <h5>Tipo</h5>
                    <select required name="tipo" id="tipo" class="form-control" value="<?php echo e(old('tipo')); ?>">
                        <option value="n">Nacional</option>
                        <option value="i">Importacion</option>
                        <option value="e">Exportacion</option>
                        <option value="c">Cruce</option>
                    </select>
                    </div>

                    <div class="form-group">
                        <h5 for="">Fecha</h5>
                        <input required type="text" required readonly name="fecha" id="fecha" class="form-control <?php echo e($errors->has('fecha')?'is-invalid':''); ?>" value="<?php echo e(old('fecha')); ?>">
                        <?php echo $errors->first('fecha','<div class="invalid-feedback">:message</div>'); ?>

                    </div>

                    <div class="form-group">
                        <h5 for="">Cliente</h5>
                            <select name="clientes" id="clientes" class="form-control" value="<?php echo e(old('clientes')); ?>">
                                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>

                    <div class="form-group">
                        <h5 for="">Ruta</h5>
                        <select required name="rutas" id="rutas" class="form-control" value="<?php echo e(old('rutas')); ?>">
                        <?php $__currentLoopData = $rutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ruta->id); ?>"><?php echo e($ruta->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <h5 for="">Unidad</h5>
                        <select required name="unidad" id="unidad" class="form-control" value="<?php echo e(old('unidad')); ?>">
                            <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($unidad->id); ?>"><?php echo e($unidad->economico); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <h5 for="">Remolque</h5>
                        <select required name="remolque" id="remolque" class="form-control" value="<?php echo e(old('remolque')); ?>">
                            <?php $__currentLoopData = $remolques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remolque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($remolque->id); ?>"><?php echo e($remolque->economico); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <h5 for="">Operador</h5>
                        <select required name="operador" id="operador" class="form-control" value="<?php echo e(old('operador')); ?>">
                            <?php $__currentLoopData = $operadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($operador->id); ?>"><?php echo e($operador->nombre_corto); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <h5>Referencia</h5>
                        <input required maxlength="20" type="text" class="form-control" name="referencia" id="referencia" value="<?php echo e(old('referencia')); ?>">
                    </div>

                    <div class="form-group">
                        <div class="form-group">
                            <h5 for="">Fecha de Embarque</h5>
                            <input type="text" required readonly name="fechaDeEmbarque" id="fechaDeEmbarque" class="form-control <?php echo e($errors->has('fechaDeEmbarque')?'is-invalid':''); ?>" value="<?php echo e(old('fechaDeEmbarque')); ?>">
                            <?php echo $errors->first('fechaDeEmbarque','<div class="invalid-feedback">:message</div>'); ?>

                        </div>
                    </div>

                    <div class="form-group">
                        <div class="form-group">
                            <h5 for="">Fecha de Entrega</h5>
                            <input type="text" required readonly name="fechaDeEntrega" id="fechaDeEntrega" class="form-control <?php echo e($errors->has('fechaDeEntrega')?'is-invalid':''); ?>" value="<?php echo e(old('fechaDeEntrega')); ?>">
                            <?php echo $errors->first('fechaDeEntrega','<div class="invalid-feedback">:message</div>'); ?>

                        </div>
                    </div>

                    <button id="guardarCartaPorte" type="submit" class="btn btn-info"><i class="far fa-save"></i> Guardar</button>
                </form>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/cartaPorte/cartaPorte.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/cartaPorte/cartaPorteCreate.blade.php ENDPATH**/ ?>