<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">MENU PRINCIPAL</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="table-responsive">
                        <table class="table table-hover table-sm">
                            <thead>
                            <th>Seccion</th>
                            <th>Listado</th>
                            <th>Nuevo</th>
                            </thead>
                            <tr>
                                <td><h2>Cliente</h2></td>
                                <td><a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-info btn-block">Listado Clientes</a></td>
                                <td><a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-info btn-block">Nuevo Cliente</a></td>
                            </tr>
                            <tr>
                                <td><h2>Operadores</h2></td>
                                <td><a href="<?php echo e(route('operadores.index')); ?>" class="btn btn-info btn-block">Listado Operadores</a></td>
                                <td><a href="<?php echo e(route('operadores.create')); ?>" class="btn btn-info btn-block">Nuevo Operador</a></td>
                            </tr>
                            <tr>
                                <td><h2>Provedores</h2></td>
                                <td><a href="<?php echo e(route('provedores.index')); ?>" class="btn btn-info btn-block">Listado Provedores</a></td>
                                <td><a href="<?php echo e(route('provedores.create')); ?>" class="btn btn-info btn-block">Nuevo Provedor</a></td>
                            </tr>
                            <tr>
                                <td><h2>Rutas</h2></td>
                                <td><a href="<?php echo e(route('rutas.index')); ?>" class="btn btn-info btn-block">Listado Rutas</a></td>
                                <td><a href="<?php echo e(route('rutas.create')); ?>" class="btn btn-info btn-block">Nuevo Rutas</a></td>
                            </tr>
                            <tr>
                                <td><h2>Unidades</h2></td>
                                <td><a href="<?php echo e(route('unidades.index')); ?>" class="btn btn-info btn-block">Listado Unidades</a></td>
                                <td><a href="<?php echo e(route('unidades.create')); ?>" class="btn btn-info btn-block">Nuevo Unidad</a></td>
                            </tr>
                            <tr>
                                <td><h2>Usuarios</h2></td>
                                <td><a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-info btn-block">Listado Usuarios</a></td>
                                <td><a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-info btn-block">Nuevos Usuarios</a></td>
                            </tr>
                        </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GEORGE/sail/resources/views/home.blade.php ENDPATH**/ ?>