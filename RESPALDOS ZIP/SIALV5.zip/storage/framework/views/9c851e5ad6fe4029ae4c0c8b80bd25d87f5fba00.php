<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-9 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-map-marked fa-md text-danger"></i> NUEVA RUTA</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('rutas.index')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div role="tabpanel">
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a href="#tab1" class="nav-link active" aria-controls="tab1" role="tab" data-toggle="tab">Rutas</a>
                        </li>
                        <li class="nav-item">
                            <a href="#tab2" class="nav-link" aria-controls="tab2" role="tab" data-toggle="tab">Datos Facturacion</a>
                        </li>
                        <li class="nav-item">
                            <a href="#tab3" class="nav-link" aria-controls="tab3" role="tab" data-toggle="tab">Datos Cuenta Por Pagar</a>
                        </li>

                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="tab1">
                            <form action="<?php echo e(route('rutas.store')); ?>" method="post" id="rutasForm">

                                <!-- ======DATOS PARA ACTIVIDAD====== -->
                                <input type="hidden" value="<?php echo e(now()); ?>" name="fecha" id="fecha">
                                <?php if(empty($actividad->ref->id)): ?>
                                    <input type="hidden" value="1" name="ref" id="ref">
                                <?php else: ?>
                                    <input type="hidden" value="<?php echo e($actividad->ref->id+1); ?>" name="ref" id="ref">
                                <?php endif; ?>
                                <input type="hidden" name="token" id="tokenFormRutas" value="<?php echo e(csrf_token()); ?>">
                                <input type="hidden" name="token" id="tokenActividad" value="<?php echo e(csrf_token()); ?>">

                                <input type="hidden" name="tabla" id="tabla" value="<?php echo e($actividad->tabla); ?>">

                                <input type="hidden" name="status" id="status" value="<?php echo e($actividad->status); ?>">

                                <input type="hidden" name="descripcion" id="descripcion" value="<?php echo e($actividad->descripcion); ?>">

                                <input type="hidden" name="usuario" id="usuario" value="<?php echo e($actividad->usuario); ?>">
                                <!-- ======DATOS PARA ACTIVIDAD====== -->

                                <div class="form-group">
                                    <h5 for="">Nombre de ruta</h5>
                                    <input maxlength="20" required type="text" name="nombre" id="nombre" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Clientes</h5>
                                    <select name="clientes" required id="clientes" class="form-control">
                                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Lugar de expedicion</h5>
                                    <input maxlength="50" required type="text" name="lugar_exp" id="lugar_exp" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Origen</h5>
                                    <input maxlength="50" required type="text" name="origen" id="origen" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Remitente</h5>
                                    <input maxlength="50" required type="text" name="remitente" id="remitente" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Domicilio del remitente</h5>
                                    <input maxlength="50" required type="text" name="dom_remitente" id="dom_remitente" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Se recoge en</h5>
                                    <input maxlength="50" required type="text" name="recoge" id="recoge" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Valor declarado</h5>
                                    <input maxlength="50" required type="text" name="valor_declarado" id="valor_declarado" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Destino</h5>
                                    <input maxlength="50" required type="text" name="destino" id="destino" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Destinatario</h5>
                                    <input maxlength="50" required type="text" name="destinatario" id="destinatario" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Domicilio del destinatario</h5>
                                    <input maxlength="50" required type="text" name="dom_destinatario" id="dom_destinatario" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Se entrega en</h5>
                                    <input maxlength="50" required type="text" name="entrega" id="entrega" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Fecha estimada de entrega</h5>
                                    <input maxlength="50" required type="text" name="fecha_entrega" id="fecha_entrega" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Cantidad</h5>
                                    <input maxlength="50" required type="text" name="cantidad" id="cantidad" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Embalaje</h5>
                                    <input maxlength="50" required type="text" name="embalaje" id="embalaje" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Concepto</h5>
                                    <input maxlength="50" required type="text" name="concepto" id="concepto" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Material peligroso</h5>
                                    <input maxlength="50" required type="text" name="material_peligroso" id="material_peligroso" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Indemnizacion</h5>
                                    <input maxlength="50" required type="text" name="indemnizacion" id="indemnizacion" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">Importe</h5>
                                    <input required type="number" min="0" name="importe" id="importe" class="form-control">
                                </div>

                                <div class="form-group">
                                <h5 for="">Asignacion de precio</h5>
                                <select name="asignacion_precio" required id="asignacion_precio" class="form-control">
                                    <?php $__currentLoopData = $provedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($provedor->id); ?>" selected><?php echo e($provedor->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Observaciones</h5>
                                    <input maxlength="50" required type="text" name="obs" id="obs" class="form-control">
                                </div>

                                <div class="form-group">
                                    <h5 for="">dias para recuperacion de evidencias</h5>
                                    <select name="dias_re" required id="dias_re" class="form-control">
                                        <?php for($j=1; $j<11; $j++): ?>
                                            <option value="<?php echo e($j); ?>"><?php echo e($j); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-info" id="guardarRutasBtn">Guardar</button>
                            </form>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="tab2">
                            <form action="<?php echo e(route('datosFacturacions.store')); ?>" method="post" id="dFacturacionForm">
                                <!-- ======DATOS PARA ACTIVIDAD====== -->
                                <input type="hidden" value="<?php echo e(now()); ?>" name="fecha" id="fechaDfacturacion">
                                <?php if(empty($actividadDatosFacturacion->ref->id)): ?>
                                    <input type="hidden" value="1" name="ref" id="refDfacturacion">
                                <?php else: ?>
                                    <input type="hidden" value="<?php echo e($actividadDatosFacturacion->ref->id+1); ?>" name="ref" id="refDfacturacion">
                                <?php endif; ?>
                                <input type="hidden" name="token" id="tokenDfacturacionActividad" value="<?php echo e(csrf_token()); ?>">

                                <input type="hidden" name="tabla" id="tablaDfacturacion" value="<?php echo e($actividadDatosFacturacion->tabla); ?>">

                                <input type="hidden" name="status" id="statusDfacturacion" value="<?php echo e($actividadDatosFacturacion->status); ?>">

                                <input type="hidden" name="descripcion" id="descripcionDfacturacion" value="<?php echo e($actividadDatosFacturacion->descripcion); ?>">

                                <input type="hidden" name="usuario" id="usuarioDfacturacion" value="<?php echo e($actividadDatosFacturacion->usuario); ?>">
                                <!-- ======DATOS PARA ACTIVIDAD====== -->
                                <input type="hidden" name="token" id="tokenFormDfacturacion" value="<?php echo e(csrf_token()); ?>">
                                <div class="form-group">
                                    <h5 for="">Rutas</h5>
                                    <select name="rutas" required id="rutasSelect" class="form-control">
                                        <?php $__currentLoopData = $rutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ruta->id); ?>"><?php echo e($ruta->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Razon social que factura</h5>
                                    <select name="facturador" id="facturador" class="form-control">
                                        <option value="1">RUBEN GUTIERREZ VELAZCO</option>
                                        <option value="2">TRANSPORTES LOGIEXPRESS SA DE CV</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Asignacion de precio</h5>
                                    <select name="asignacionPrecio" required id="asignacionPrecio" class="form-control">
                                        <?php $__currentLoopData = $provedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($provedor->id); ?>"><?php echo e($provedor->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Clave de Prod o Servicio</h5>
                                    <input maxlength="20" type="text" required name="claveProdServ" id="claveProdServ" class="form-control <?php echo e($errors->has('claveProdServ')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('claveProdServ')); ?>">
                                    <div class="invalid-feedback">
                                        El campo claveProdServ es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Numero de Identificacion</h5>
                                    <input maxlength="20" type="text" required name="noIdentificacion" id="noIdentificacion" class="form-control <?php echo e($errors->has('noIdentificacion')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('noIdentificacion')); ?>">
                                    <div class="invalid-feedback">
                                        El campo noIdentificacion es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Cantidad</h5>
                                    <input type="number" min="0" required name="cantidad" id="cantidadDfacturacion" class="form-control <?php echo e($errors->has('cantidadDatosFacturacion')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('cantidadDatosFacturacion')); ?>">
                                    <div class="invalid-feedback">
                                        El campo cantidad es requerido y debe de ser numerico
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Clave Unidad</h5>
                                    <input maxlength="20" type="text" required name="claveUnidad" id="claveUnidad" class="form-control <?php echo e($errors->has('claveUnidad')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('claveUnidad')); ?>">
                                    <div class="invalid-feedback">
                                        La campo claveUnidad es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Unidad</h5>
                                    <input maxlength="20" type="text" required name="unidad" id="unidad" class="form-control <?php echo e($errors->has('unidad')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('unidad')); ?>">
                                    <div class="invalid-feedback">
                                        La campo unidad es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Descripcion</h5>
                                    <input maxlength="50" type="text" required name="descripcion" id="descripcion" class="form-control <?php echo e($errors->has('descripcion')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('descripcion')); ?>">
                                    <div class="invalid-feedback">
                                        El campo descripcion es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Valor Unitario</h5>
                                    <input type="number" min="0" required name="valorUnitario" id="valorUnitario" class="form-control <?php echo e($errors->has('valorUnitario')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('valorUnitario')); ?>">
                                    <div class="invalid-feedback">
                                        El campo valorUnitario es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Importe</h5>
                                    <input type="number" min="0" required name="importeF" id="importeF" class="form-control <?php echo e($errors->has('importe')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('importe')); ?>">
                                    <div class="invalid-feedback">
                                        El campo importe es requerido y debe de ser numerico
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Traslado de Iva (Porcentaje)</h5>
                                    <input type="number" min="0" required name="tIva" id="tIva" class="form-control <?php echo e($errors->has('tIva')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('tIva')); ?>">
                                    <div class="invalid-feedback">
                                        El campo tIva es requerido y debe de ser numerico
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Traslado de Isr (Porcentaje)</h5>
                                    <input type="number" min="0" required name="tIsr" id="tIsr" class="form-control <?php echo e($errors->has('tIsr')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('tIsr')); ?>">
                                    <div class="invalid-feedback">
                                        El campo tIsr es requerido y debe de ser numerico
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Retencion de Iva (Porcentaje)</h5>
                                    <input type="number" min="0" required name="rIva" id="rIva" class="form-control <?php echo e($errors->has('rIva')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('rIva')); ?>">
                                    <div class="invalid-feedback">
                                        El campo rIva es requerido y debe de ser numerico
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Retencion de Isr (Porcentaje)</h5>
                                    <input type="number" min="0" required name="rIsr" id="rIsr" class="form-control <?php echo e($errors->has('rIsr')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('rIsr')); ?>">
                                    <div class="invalid-feedback">
                                        El campo rIsr es requerido y debe de ser numerico
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary" id="guardarDfacturacionBtn">Guardar</button>
                            </form>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="tab3">
                            <form action="<?php echo e(route('datosCporPagar.store')); ?>" id="datosCxP">
                                <!-- ======DATOS PARA ACTIVIDAD====== -->
                                <input type="hidden" value="<?php echo e(now()); ?>" name="fecha" id="fechaDCxP">
                                <?php if(empty($actividadDCxP->ref->id)): ?>
                                    <input type="hidden" value="1" name="ref" id="refDCxP">
                                <?php else: ?>
                                    <input type="hidden" value="<?php echo e($actividadDCxP->ref->id+1); ?>" name="ref" id="refDCxP">
                                <?php endif; ?>
                                <input type="hidden" name="token" id="tokenDCxP" value="<?php echo e(csrf_token()); ?>">

                                <input type="hidden" name="tabla" id="tablaDCxP" value="<?php echo e($actividadDCxP->tabla); ?>">

                                <input type="hidden" name="status" id="statusDCxP" value="<?php echo e($actividadDCxP->status); ?>">

                                <input type="hidden" name="descripcion" id="descripcionDCxP" value="<?php echo e($actividadDCxP->descripcion); ?>">

                                <input type="hidden" name="usuario" id="usuarioDCxP" value="<?php echo e($actividadDCxP->usuario); ?>">
                                <!-- ======DATOS PARA ACTIVIDAD====== -->
                                <input type="hidden" name="token" id="tokenFormDatosCxP" value="<?php echo e(csrf_token()); ?>">
                                <div class="form-group">
                                    <h5 for="">Rutas</h5>
                                    <select name="rutas" required id="rutasCxP" class="form-control">
                                        <?php $__currentLoopData = $rutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ruta->id); ?>"><?php echo e($ruta->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Concepto</h5>
                                    <select required name="concepto" id="conceptoCxP" class="form-control">
                                        <option value="1">Flete</option>
                                        <option value="2">Maniobras</option>
                                        <option value="3">Estadias</option>
                                        <option value="4">Cruce</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Asignacion de precio</h5>
                                    <select name="asignacionPrecio" required id="asignacionPrecioCxP" class="form-control">
                                        <?php $__currentLoopData = $provedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($provedor->id); ?>"><?php echo e($provedor->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Clave de Producto o Servicio</h5>
                                    <input maxlength="20" type="text" required name="claveProdServ" id="claveProdServCxP" class="form-control <?php echo e($errors->has('claveProdServ')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('claveProdServ')); ?>">
                                    <div class="invalid-feedback">
                                        El campo claveProdServ es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Numero de identificacion</h5>
                                    <input maxlength="20" type="text" required name="noIdentificacion" id="noIdentificacionCxP" class="form-control <?php echo e($errors->has('noIdentificacion')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('noIdentificacion')); ?>">
                                    <div class="invalid-feedback">
                                        El campo noIdentificacion es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Cantidad</h5>
                                    <input type="number" required name="cantidad" id="cantidadCxP" class="form-control <?php echo e($errors->has('cantidad')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('cantidad')); ?>">
                                    <div class="invalid-feedback">
                                        El campo cantidad es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Clave unidad</h5>
                                    <input maxlength="20" type="text" required name="claveUnidad" id="claveUnidadCxP" class="form-control <?php echo e($errors->has('claveUnidad')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('claveUnidad')); ?>">
                                    <div class="invalid-feedback">
                                        El campo claveUnidad es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Unidad</h5>
                                    <input maxlength="20" type="text" required name="unidad" id="unidadCxP" class="form-control <?php echo e($errors->has('unidad')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('unidad')); ?>">
                                    <div class="invalid-feedback">
                                        El campo unidad es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Descripcion</h5>
                                    <input maxlength="50" type="string" required name="descripcion" id="descripcionCxP" class="form-control <?php echo e($errors->has('descripcion')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('descripcion')); ?>">
                                    <div class="invalid-feedback">
                                        El campo descripcion es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Valor Unitario</h5>
                                    <input type="number" required name="valorUnitario" id="valorUnitarioCxP" class="form-control <?php echo e($errors->has('valorUnitario')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('valorUnitario')); ?>">
                                    <div class="invalid-feedback">
                                        El campo valorUnitario es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Importe</h5>
                                    <input type="number" required name="importe" id="importeCxP" class="form-control <?php echo e($errors->has('importe')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('importe')); ?>">
                                    <div class="invalid-feedback">
                                        El campo importe es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Traslado de Iva (Porcentaje)</h5>
                                    <input type="number" required name="tiva" id="tivaCxP" class="form-control <?php echo e($errors->has('tiva')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('tiva')); ?>">
                                    <div class="invalid-feedback">
                                        El campo tiva es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Traslado de Isr (Porcentaje)</h5>
                                    <input type="number" required name="tisr" id="tisrCxP" class="form-control <?php echo e($errors->has('tisr')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('tisr')); ?>">
                                    <div class="invalid-feedback">
                                        El campo tisr es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Retencion de Iva (Porcentaje)</h5>
                                    <input type="number" required name="riva" id="rivaCxP" class="form-control <?php echo e($errors->has('riva')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('riva')); ?>">
                                    <div class="invalid-feedback">
                                        El campo riva es requerido
                                    </div>
                                </div>

                                <div class="form-group">
                                    <h5 for="">Retencion de Isr (Porcentaje)</h5>
                                    <input type="number" required name="risr" id="risrCxP" class="form-control <?php echo e($errors->has('risr')?'is-invalid':''); ?>"
                                           value="<?php echo e(old('risr')); ?>">
                                    <div class="invalid-feedback">
                                        El campo risr es requerido
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary" id="guardarDxP">Guardar</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <script src="<?php echo e(asset('js/ruta/rutaCreate.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/ruta/rutaCreate.blade.php ENDPATH**/ ?>