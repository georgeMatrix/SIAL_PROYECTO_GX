<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-9 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-map-marked fa-md text-danger"></i> ACTUALIZACION FACTURACION DATOS CUENTAS POR PAGAR</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('rutas.index')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(url('/datosCporPagar/'.$datosCxP->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>

                    <h5 for="">Rutas</h5>
                    <select name="ruta" id="ruta" class="form-control">
                        <?php $__currentLoopData = $rutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($datosCxP->rutas == $ruta->id): ?>
                                <option value="<?php echo e($ruta->id); ?>" selected><?php echo e($ruta->nombre); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($ruta->id); ?>"><?php echo e($ruta->nombre); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <h5 for="">Concepto</h5>
                    <select required name="concepto" id="conceptoCxP" class="form-control">
                        <option value="1">Flete</option>
                        <option value="2">Maniobras</option>
                        <option value="3">Estadias</option>
                        <option value="4">Cruce</option>
                    </select>

                    <h5 for="">Asignacion de Precio</h5>
                    <select name="asignacionPrecio" id="asignacionPrecio" class="form-control">
                        <?php $__currentLoopData = $provedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($provedor->id == $datosCxP->asignacionPrecio): ?>
                                <option value="<?php echo e($provedor->id); ?>" selected><?php echo e($provedor->nombre); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($provedor->id); ?>"><?php echo e($provedor->nombre); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <h5 for="">Clave de Producto o Servicio</h5>
                    <input type="text" required name="claveprodserv" id="claveprodserv" class="form-control"  value="<?php echo e($datosCxP->claveProdServ); ?>">
                    <h5 for="">Numero de Identificacion</h5>
                    <input type="text" required name="noIdentificacion" id="noIdentificacion" class="form-control"  value="<?php echo e($datosCxP->noIdentificacion); ?>">
                    <h5 for="">Cantidad</h5>
                    <input type="text" required name="cantidad" id="cantidad" class="form-control"  value="<?php echo e($datosCxP->cantidad); ?>">
                    <h5 for="">Clave Unidad</h5>
                    <input type="text" required name="claveUnidad" id="claveUnidad" class="form-control"  value="<?php echo e($datosCxP->claveUnidad); ?>">
                    <h5 for="">Unidad</h5>
                    <input type="text" required name="unidad" id="unidad" class="form-control"  value="<?php echo e($datosCxP->unidad); ?>">
                    <h5 for="">Descripcion</h5>
                    <input type="text" required name="descripcion" id="descripcion" class="form-control"  value="<?php echo e($datosCxP->descripcion); ?>">
                    <h5 for="">Valor unitario</h5>
                    <input type="text" required name="valorUnitario" id="valorUnitario" class="form-control"  value="<?php echo e($datosCxP->valorUnitario); ?>">
                    <h5 for="">Importe</h5>
                    <input type="text" required name="importe" id="importe" class="form-control"  value="<?php echo e($datosCxP->importe); ?>">
                    <h5 for="">Traslado de Iva (Porsentaje)</h5>
                    <input type="text" required name="tivaCxP" id="tivaCxP" class="form-control"  value="<?php echo e($datosCxP->tivaCxP); ?>">
                    <h5 for="">Traslado de Irs (Porcentaje)</h5>
                    <input type="text" required name="tisrCxP" id="tisrCxP" class="form-control"  value="<?php echo e($datosCxP->tisrCxP); ?>">
                    <h5 for="">Retencion de Iva (Porcentaje)</h5>
                    <input type="text" required name="rivaCxP" id="rivaCxP" class="form-control" value="<?php echo e($datosCxP->rivaCxP); ?>">
                    <h5 for="">Retencion de Isr (Porcentaje)</h5>
                    <input type="text" required name="risrCxP" id="risrCxP" class="form-control" value="<?php echo e($datosCxP->risrCxP); ?>">
                    <br>
                    <button type="submit" class="btn btn-primary">Actualizar</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GEORGE/sail/resources/views/datosCxP/datosCxPEdit.blade.php ENDPATH**/ ?>