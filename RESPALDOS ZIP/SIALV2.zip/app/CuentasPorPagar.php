<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CuentasPorPagar extends Model
{
    //
}
