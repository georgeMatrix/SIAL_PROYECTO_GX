<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-9 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="text-danger fas fa-user"></i> Nuevo Cuentas Por Pagar</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('cuentasPorPagar.index')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('cuentasPorPagar.store')); ?>" method="post" id="cuentasPorPagarForm">
                    <?php echo e(csrf_field()); ?>

                    <label for="">Carta Porte</label>
                    <select name="idCartaPorteCuentasPorPagar" id="idCartaPorteCuentasPorPagar" class="form-control">
                        <?php $__currentLoopData = $cartasPorteRelease; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartasPorteR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cartasPorteR->id); ?>"><?php echo e($cartasPorteR->id); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" value="0" name="id_datos_facturacion" id="id_datos_facturacion" class="form-control">
                    <h5 for="">Clave Producto Servicio</h5>
                    <input type="text" name="clave_prod_serv" id="clave_prod_serv" class="form-control">
                    <h5 for="">Identificacion</h5>
                    <input type="text" name="no_identificacion" id="no_identificacion" class="form-control">
                    <h5 for="">Cantidad</h5>
                    <input type="number" min="0" name="cantidad" id="cantidad" class="form-control">
                    <h5 for="">Clave unidad</h5>
                    <input type="text" name="clave_unidad" id="clave_unidad" class="form-control">
                    <h5 for="">Unidad</h5>
                    <input type="text" name="unidad" id="unidad" class="form-control">
                    <h5 for="">Descripción</h5>
                    <input type="text" name="descripcion" id="descripcion" class="form-control">
                    <h5 for="">Valor unitario</h5>
                    <input type="number" min="0" name="valor_unitario" id="valor_unitario" class="form-control">
                    <h5 for="">Importe</h5>
                    <input type="number" min="0" name="importe" id="importe" class="form-control">
                    <h5 for="">Facturador</h5>
                    <select name="emisor_razon_social" id="emisor_razon_social" class="form-control">
                        <option value="1">RUBEN GUTIERREZ VELAZCO</option>
                        <option value="2">TRANSPORTES LOGIEXPRESS SA DE CV</option>
                    </select>
                    <input type="hidden" value="" name="emisor_rfc" id="emisor_rfc">
                    <input type="hidden" value="" name="emisor_regimen" id="emisor_regimen">
                    <input type="hidden" value="" name="receptor_rfc" id="receptor_rfc">
                    <h5 for="">Cliente</h5>
                    <select name="receptor_razon_social" id="receptor_razon_social" class="form-control">
                        <option value="1">RUBEN GUTIERREZ VELAZCO</option>
                        <option value="2">TRANSPORTES LOGIEXPRESS SA DE CV</option>
                    </select>
                    <input type="hidden" value="" name="receptor_regimen" id="receptor_regimen">
                    <h5>TRASLADO IVA %</h5>
                    <input min="0" max="99" type="number" name="trasladoIva" id="trasladoIva" class="form-control">
                    <h5>TRASLADO ISR %</h5>
                    <input min="0" max="99" type="number" name="trasladoIsr" id="trasladoIsr" class="form-control">
                    <h5>RETENCION IVA %</h5>
                    <input min="0" max="99" type="number" name="retencionIva" id="retencionIva" class="form-control">
                    <h5>RETENCION ISR %</h5>
                    <input min="0" max="99" type="number" name="retencionIsr" id="retencionIsr" class="form-control">
                    <!-- ============================================================================ -->
                    <!-- ===========================HASTA AQUI SE VEN================================ -->
                    <!-- ============================================================================ -->
                    <input type="hidden" min="0" name="cfdi_t_iva_base" id="cfdi_t_iva_base" class="form-control">
                    <input type="hidden" min="0" max="99" name="cfdi_t_iva_impuesto" id="cfdi_t_iva_impuesto" class="form-control">
                    <input type="hidden" readonly name="cfdi_t_iva_tipofactor" id="cfdi_t_iva_tipofactor" class="form-control" value="Tasa">
                    <input type="hidden" min="0" name="cfdi_t_iva_tasacuota" id="cfdi_t_iva_tasacuota" class="form-control">
                    <input type="hidden" min="0" name="cfdi_t_iva_importe" id="cfdi_t_iva_importe" class="form-control">

                    <input type="hidden" min="0" name="cfdi_t_isr_base" id="cfdi_t_isr_base" class="form-control">
                    <input type="hidden" name="cfdi_t_isr_impuesto" id="cfdi_t_isr_impuesto" class="form-control">
                    <input type="hidden" min="0" max="99" name="cfdi_t_isr_tipofactor" id="cfdi_t_isr_tipofactor" class="form-control">
                    <input type="hidden" min="0" max="99" name="cfdi_t_isr_tasacuota" id="cfdi_t_isr_tasacuota" class="form-control">
                    <input type="hidden" min="0" max="99" name="cfdi_t_isr_importe" id="cfdi_t_isr_importe" class="form-control">

                    <input type="hidden" min="0" max="99" name="cfdi_r_iva_base" id="cfdi_r_iva_base" class="form-control">
                    <input type="hidden" name="cfdi_r_iva_impuesto" id="cfdi_r_iva_impuesto" class="form-control">
                    <input type="hidden" max="99" name="cfdi_r_iva_tipofactor" id="cfdi_r_iva_tipofactor" class="form-control">
                    <input type="hidden" max="99" name="cfdi_r_iva_tipofactor" id="cfdi_r_iva_tipofactor" class="form-control">
                    <input type="hidden" name="cfdi_r_iva_tasacuota" id="cfdi_r_iva_tasacuota" class="form-control">
                    <input type="hidden" name="cfdi_r_iva_importe" id="cfdi_r_iva_importe" class="form-control">

                    <input type="hidden" name="cfdi_r_isr_base" id="cfdi_r_isr_base" class="form-control">
                    <input type="hidden" name="cfdi_r_isr_impuesto" id="cfdi_r_isr_impuesto" class="form-control">
                    <input type="hidden" name="cfdi_r_isr_tipofactor" id="cfdi_r_isr_tipofactor" class="form-control">
                    <input type="hidden" name="cfdi_r_isr_tasacuota" id="cfdi_r_isr_tasacuota" class="form-control">
                    <input type="hidden" name="cfdi_r_isr_importe" id="cfdi_r_isr_importe" class="form-control">

                    <button class="btn btn-success">Guardar</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $("#cuentasPorPagarForm").submit(function () {
            $('#emisor_rfc').val($("#emisor_razon_social").val());
            $('#emisor_regimen').val($("#emisor_rfc").val());
            $('#receptor_rfc').val($("#receptor_razon_social").val());
            $('#receptor_regimen').val($("#receptor_razon_social").val())
            
            if ($("#trasladoIva").val() != 0){
                $("#cfdi_t_iva_base").val('IMPORTE');
                $("#cfdi_t_iva_impuesto").val('002');
                $("#cfdi_t_iva_tipofactor").val('Tasa');
                let iva = $("#trasladoIva").val()/100;
                $("#cfdi_t_iva_tasacuota").val(iva);
                let importe = $("#importe").val()/$("#trasladoIva").val();
                $("#cfdi_t_iva_importe").val(importe);
            }

            if ($("#trasladoIsr").val() != 0){
                $("#cfdi_t_isr_base").val('IMPORTE');
                $("#cfdi_t_isr_impuesto").val('001');
                $("#cfdi_t_isr_tipofactor").val('Tasa');
                let iva = $("#trasladoIsr").val()/100;
                $("#cfdi_t_isr_tasacuota").val(iva);
                let importe = $("#importe").val()/$("#trasladoIsr").val();
                $("#cfdi_t_isr_importe").val(importe);
            }

            if ($("#retencionIva").val() != 0){
                $("#cfdi_r_iva_base").val('IMPORTE');
                $("#cfdi_r_iva_impuesto").val('002');
                $("#cfdi_r_iva_tipofactor").val('Tasa');
                let iva = $("#retencionIva").val()/100;
                $("#cfdi_r_iva_tasacuota").val(iva);
                let importe = $("#importe").val()/$("#retencionIva").val();
                $("#cfdi_r_iva_importe").val(importe);
            }

            if ($("#retencionIsr").val() != 0){
                $("#cfdi_r_isr_base").val('IMPORTE');
                $("#cfdi_r_isr_impuesto").val('002');
                $("#cfdi_r_isr_tipofactor").val('Tasa');
                let iva = $("#retencionIsr").val()/100;
                $("#cfdi_r_isr_tasacuota").val(iva);
                let importe = $("#importe").val()/$("#retencionIsr").val();
                $("#cfdi_r_isr_importe").val(importe);
            }
        })

    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/cuentasPorPagar/cuentasPorPagarCreate.blade.php ENDPATH**/ ?>