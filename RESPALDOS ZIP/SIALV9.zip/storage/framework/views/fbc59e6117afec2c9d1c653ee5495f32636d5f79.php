<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Generacion de Release</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
                <table class="table table-responsive">
                    <thead>
                    <th>RELEASE</th>
                    <th>ID</th>
                    <th>TIPO</th>
                    <th>FECHA</th>
                    <th>RUTA</th>
                    <th>UNIDAD</th>
                    <th>REMOLQUE</th>
                    <th>OPERADOR</th>
                    <th>REFERENCIA</th>
                    <th>FECHA_EMBARQUE</th>
                    <th>FECHA_ENTREGA</th>
                    <th>STATUS</th>
                    <th>ULTIMO_STATUS</th>
                    <th>FECHA_STATUS</th>
                    </thead>
                    <?php $__currentLoopData = $release; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="rows">
                        <td><input type="checkbox" class="form-control" id="release"></td>
                        <?php $__currentLoopData = $nacional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rel->id == $n->cartaPorte): ?>
                                <td><?php echo e($n->id); ?></td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $importacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rel->id == $i->cartaPorte): ?>
                                <td><?php echo e($i->id); ?></td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $exportacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rel->id == $e->cartaPorte): ?>
                                <td><?php echo e($e->id); ?></td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $cruce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($rel->id == $c->cartaPorte): ?>
                                <td><?php echo e($c->id); ?></td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td id="idValorRelease"><?php echo e($rel->id); ?></td>
                        <td><?php echo e($rel->tipo); ?></td>
                        <td><?php echo e($rel->fecha); ?></td>
                        <td><?php echo e($rel->rutaCartaP->nombre); ?></td>
                        <td><?php echo e($rel->unidadesF->economico); ?></td>
                        <td><?php echo e($rel->remolquesF->economico); ?></td>
                        <td><?php echo e($rel->operadorF->nombre_corto); ?></td>
                        <td><?php echo e($rel->referencia); ?></td>
                        <td><?php echo e($rel->fechaDeEmbarque); ?></td>
                        <td><?php echo e($rel->fechaDeEntrega); ?></td>
                        <td><?php echo e($rel->status); ?></td>
                        <?php for($i=1; $i<=$cP->id; $i++): ?>
                            <?php if($ultimo[$i]->ref == $cP->id): ?>
                                <td><?php echo e($ultimo[$i]->status); ?></td>
                            <?php endif; ?>
                        <?php endfor; ?>
                        <?php for($i=1; $i<=$cP->id; $i++): ?>
                            <?php if($ultimo[$i]->ref == $cP->id): ?>
                                <td><?php echo e($ultimo[$i]->fecha); ?></td>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="window.location.reload()">Cerrar</button>
                <button type="button" class="btn btn-primary" id="cambioRelease" onclick="cambioAbiertaToRelease()">Generar</button>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/include/modalCartaPorte.blade.php ENDPATH**/ ?>