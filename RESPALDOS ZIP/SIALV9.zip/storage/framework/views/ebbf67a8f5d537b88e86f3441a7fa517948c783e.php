<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-6 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-truck fa-md text-danger"></i> LISTADO UNIDADES</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('unidades.create')); ?>" class="mt-3 btn btn-info float-right"><i class="fas fa-user"></i> Nueva Unidad</a>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(url('/home')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-hover table-sm table-striped">
                    <thead class="table-info">
                    <tr>
                        <th>ID</th>
                        <th>PROVEEDOR</th>
                        <th>NOMBRE_DE_LA_UNIDAD</th>
                        <th>ECONOMICO</th>
                        <th>TIPO_DE_UNIDAD</th>
                        <th>MARCA</th>
                        <th>MODELO</th>
                        <th>PLACAS</th>
                        <th>NUMERO_DE_SERIE_DE_CHASIS</th>
                        <th>NUMERO_DE_SERIE_DE_MOTOR</th>
                        <th>VENCIMIENTO_DE_POLIZA_DE_SEGURO</th>
                        <th>VENCIMIENTO_DE_VERIFICACION</th>
                        <th>VENCIMIENTO_DE_FISICO_MECANICA</th>
                        <th>OBSERVACIONES</th>
                        <th>ELIMINAR_REGISTRO</th>
                        <th>ACTUALIZAR_REGISTRO</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($unidad->id); ?></td>
                            <?php $__currentLoopData = $provedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($provedor->id == $unidad->provedor): ?>
                                    <td><?php echo e($provedor->nombre); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($unidad->nombre); ?></td>
                            <td><?php echo e($unidad->economico); ?></td>
                            <td><?php echo e($unidad->tipo); ?></td>
                            <td><?php echo e($unidad->marca); ?></td>
                            <td><?php echo e($unidad->modelo); ?></td>
                            <td><?php echo e($unidad->placas); ?></td>
                            <td><?php echo e($unidad->serie); ?></td>
                            <td><?php echo e($unidad->motor); ?></td>
                            <td><?php echo e($unidad->seguro); ?></td>
                            <td><?php echo e($unidad->verificacion); ?></td>
                            <td><?php echo e($unidad->fm); ?></td>
                            <td><?php echo e($unidad->obs); ?></td>
                            <td>
                                <form method="post" action="<?php echo e(url('/unidades/'.$unidad->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" onclick="return confirm('Eliminar');" class="btn btn-danger"><i class="far fa-trash-alt"></i> Eliminar</button>
                                </form>
                            </td>
                            <td>
                                <a href="<?php echo e(url('/unidades/'.$unidad->id.'/edit')); ?>" class="btn btn-primary"><i class="far fa-edit"></i>Editar</a>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                </div>
                <?php echo e($unidades->render()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GEORGE/sail/resources/views/unidad/unidades.blade.php ENDPATH**/ ?>