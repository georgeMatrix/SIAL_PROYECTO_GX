<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-9 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="text-danger fas fa-user"></i> NUEVO CLIENTE</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('clientes.index')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('clientes.store')); ?>" method="post" id="formularioCliente">
                <?php echo e(csrf_field()); ?>

                <?php if(empty($id->id)): ?>
                    <input type="hidden" value="1" name="id">
                <?php else: ?>
                    <input type="hidden" value="<?php echo e($id->id+1); ?>" name="id">
                <?php endif; ?>

                <div class="form-group">
                    <h5 for="">Nombre</h5>
                    <input maxlength="70" required type="text" name="nombre" id="nombre" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Calle</h5>
                    <input maxlength="70" required type="text" name="calle" id="calle" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Numero</h5>
                    <input maxlength="10" required type="text" name="numero" id="numero" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Interior</h5>
                    <input maxlength="10" required type="text" name="interior" id="interior" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Colonia</h5>
                    <input maxlength="70" required type="text" name="colonia" id="colonia" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Ciudad</h5>
                    <input maxlength="70" required type="text" name="ciudad" id="ciudad" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Cp</h5>
                    <input maxlength="10" required type="text" name="cp" id="cp" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Estado</h5>
                    <input maxlength="20" required type="text" name="estado" id="estado" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Contacto 1</h5>
                    <input maxlength="50" required type="text" name="contacto1" id="contacto1" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Telefono 1</h5>
                    <input maxlength="20" required type="text" name="tel1" id="tel1" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Mail 1</h5>
                    <input maxlength="50" required type="email" name="mail1" id="mail1" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Contacto 2</h5>
                    <input maxlength="50" required type="text" name="contacto2" id="contacto2" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Telefono 2</h5>
                    <input maxlength="20" required type="text" name="tel2" id="tel2" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Mail 2</h5>
                    <input maxlength="50" required type="email" name="mail2" id="mail2" class="form-control">
                </div>

                <div class="form-group">
                    <h5 for="">Dia Revision</h5>
                    <select required name="dia_revision" id="dia_revision" class="form-control">
                        <option value="1">LUNES</option>
                        <option value="2">MARTES</option>
                        <option value="3">MIERCOLES</option>
                        <option value="4">JUEVES</option>
                        <option value="5">VIERNES</option>
                    </select>
                </div>

                <div class="form-group">
                    <h5 for="">Dia Credito</h5>
                    <select required name="dia_credito" id="dia_credito" class="form-control">
                        <?php for($i=1; $i<100; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    
                </div>

                <button id="guardarCliente" type="submit" class="btn btn-info"><i class="far fa-save"></i> Guardar</button>
            </form>
        </div>
    </div>
    </div>
    <script>
        $(document).ready(function() {
            $("#formularioCliente").on('submit', function(){
                $("#guardarCliente").prop("disabled", true);
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GEORGE/sail/resources/views/cliente/clienteCreate.blade.php ENDPATH**/ ?>