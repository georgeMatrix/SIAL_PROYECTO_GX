<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-9 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-map-marked fa-md text-danger"></i> ACTUALIZACION FACTURACION</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('rutas.index')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(url('/datosFacturacions/'.$datosF->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PATCH')); ?>

                <h5 for="">Rutas</h5>
                <select name="rutas" id="rutas" class="form-control">
                    <?php $__currentLoopData = $rutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($datosF->rutas == $ruta->id): ?>
                            <option value="<?php echo e($ruta->id); ?>" selected><?php echo e($ruta->nombre); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($ruta->id); ?>"><?php echo e($ruta->nombre); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <h5 for="">Razon social que factura</h5>
                <select name="facturador" id="facturador" class="form-control">
                        <?php if($datosF->facturador == 1): ?>
                            <option value="1" selected>RUBEN GUTIERREZ VELAZCO</option>
                            <option value="2">TRANSPORTES LOGIEXPRESS SA DE CV</option>
                        <?php else: ?>
                            <option value="1">RUBEN GUTIERREZ VELAZCO</option>
                            <option value="2" selected>TRANSPORTES LOGIEXPRESS SA DE CV</option>
                        <?php endif; ?>
                </select>

                <h5 for="">Clientes</h5>
                <select name="clientes" id="clientes" class="form-control">
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($datosF->clientesF->id == $cliente->id): ?>
                            <option value="<?php echo e($cliente->id); ?>" selected><?php echo e($cliente->nombre); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <h5 for="">Asignacion de Precio</h5>
                <select name="asignacionPrecio" id="asignacionPrecio" class="form-control">
                    <?php $__currentLoopData = $provedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($provedor->id == $datosF->asignacionPrecio): ?>
                            <option value="<?php echo e($provedor->id); ?>" selected><?php echo e($provedor->nombre); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($provedor->id); ?>"><?php echo e($provedor->nombre); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <h5 for="">Clave de Producto o Servicio</h5>
                <input type="text" required name="claveprodserv" id="claveprodserv" class="form-control"  value="<?php echo e($datosF->claveProdServ); ?>">
                <h5 for="">Numero de Identificacion</h5>
                <input type="text" required name="noIdentificacion" id="noIdentificacion" class="form-control"  value="<?php echo e($datosF->noIdentificacion); ?>">
                <h5 for="">Cantidad</h5>
                <input type="text" required name="cantidad" id="cantidad" class="form-control"  value="<?php echo e($datosF->cantidad); ?>">
                <h5 for="">Clave Unidad</h5>
                <input type="text" required name="claveUnidad" id="claveUnidad" class="form-control"  value="<?php echo e($datosF->claveUnidad); ?>">
                <h5 for="">Unidad</h5>
                <input type="text" required name="unidad" id="unidad" class="form-control"  value="<?php echo e($datosF->unidad); ?>">
                <h5 for="">Descripcion</h5>
                <input type="text" required name="descripcion" id="descripcion" class="form-control"  value="<?php echo e($datosF->descripcion); ?>">
                <h5 for="">Valor unitario</h5>
                <input type="text" required name="valorUnitario" id="valorUnitario" class="form-control"  value="<?php echo e($datosF->valorUnitario); ?>">
                <h5 for="">Importe</h5>
                <input type="text" required name="importe" id="importe" class="form-control"  value="<?php echo e($datosF->importe); ?>">
                <h5 for="">Traslado de Iva (Porsentaje)</h5>
                <input type="text" required name="tIva" id="tIva" class="form-control"  value="<?php echo e($datosF->tIva); ?>">
                <h5 for="">Traslado de Irs (Porcentaje)</h5>
                <input type="text" required name="tIsr" id="tIsr" class="form-control"  value="<?php echo e($datosF->tIsr); ?>">
                <h5 for="">Retencion de Iva (Porcentaje)</h5>
                <input type="text" required name="rIva" id="rIva" class="form-control" value="<?php echo e($datosF->rIva); ?>">
                <h5 for="">Retencion de Isr (Porcentaje)</h5>
                <input type="text" required name="rIsr" id="rIsr" class="form-control" value="<?php echo e($datosF->rIsr); ?>">
                <button type="submit" class="btn btn-primary">Actualizar</button>
            </form>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/datosFacturacion/datosFacturacionEdit.blade.php ENDPATH**/ ?>