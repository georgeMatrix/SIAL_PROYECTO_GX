<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-6 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="text-danger fa fa-box-open fa-md text-danger"></i> LISTADO PROVEEDORES</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('provedores.create')); ?>" class="mt-3 btn btn-info float-right"><i class="fas fa-user"></i> Nuevo Proveedor</a>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(url('/home')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-responsive table-hover table-sm">
                    <thead class="table-info">
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE_COMERCIAL_DEL_PROVEEDOR</th>
                        <th>RAZON_SOCIAL_DEL_PROVEEDOR</th>
                        <th>RFC</th>
                        <th>DIRECCION</th>
                        <th>CONTACTO</th>
                        <th>MAIL</th>
                        <th>DIAS_DE_CREDITO</th>
                        <th>ELIMINAR_REGISTRO</th>
                        <th>EDITAR_REGISTRO</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $provedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($provedor->id); ?></td>
                            <td><?php echo e($provedor->nombre); ?></td>
                            <td><?php echo e($provedor->razon_social); ?></td>
                            <td><?php echo e($provedor->rfc); ?></td>
                            <td><?php echo e($provedor->direccion); ?></td>
                            <td><?php echo e($provedor->contacto); ?></td>
                            <td><?php echo e($provedor->mail); ?></td>
                            <td><?php echo e($provedor->credito); ?></td>
                            <td>
                                <form method="post" action="<?php echo e(url('/provedores/'.$provedor->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" onclick="return confirm('Eliminar');" class="btn btn-danger"><i class="far fa-trash-alt"></i> Eliminar</button>
                                </form>
                            </td>
                            <td>
                                <a href="<?php echo e(url('/provedores/'.$provedor->id.'/edit')); ?>" class="btn btn-primary"><i class="far fa-edit"></i> Editar</a>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php echo e($provedores->render()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GEORGE/sail/resources/views/provedor/provedores.blade.php ENDPATH**/ ?>