<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-6 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-map-marked fa-md text-danger"></i> LISTADO RUTAS</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('rutas.create')); ?>" class="mt-3 btn btn-info float-right"><i class="fas fa-user"></i> Nueva Ruta</a>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(url('/home')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="row">

                    <div class="col-md-12 col-sm-12 col-xs-12 xlg-margin">
                        <h4>Accordion</h4>
                        <div class="md-margin"></div><!--space -->

                        <div class="accordion" id="accordion">
                            <div class="accordion-group panel">
                                <div class="accordion-header">
                                    <div class="accordion-title">Rutas</div><!-- End .accourdion-title -->
                                    <a class="accordion-btn" data-toggle="collapse" data-parent="#accordion" href="#accordion-one"></a>
                                </div><!-- End .accordion-header -->

                                <div class="accordion-body collapse" id="accordion-one">
                                    <div class="accordion-body-wrapper">
                                        <div class="table-responsive">
                                            <table class="table table-hover table-sm table-striped">
                                                <thead class="table-info">
                                                <tr>
                                                    <th>ID</th>
                                                    <th>NOMBRE_DE_RUTA</th>
                                                    <th>CLIENTE</th>
                                                    <th>LUGAR_EXPEDICION</th>
                                                    <th>ORIGEN</th>
                                                    <th>REMITENTE</th>
                                                    <th>DOMICILIO_DEL_REMITENTE</th>
                                                    <th>SE_RECOGE_EN</th>
                                                    <th>VALOR_DECLARADO</th>
                                                    <th>DESTINO</th>
                                                    <th>DESTINATARIO</th>
                                                    <th>DOMICILIO_DEL_DESTINATARIO</th>
                                                    <th>SE_ENTREGA_EN</th>
                                                    <th>FECHA_ESTIMADA_DE_ENTREGA</th>
                                                    <th>CANTIDAD</th>
                                                    <th>EMBALAJE</th>
                                                    <th>CONCEPTO</th>
                                                    <th>MATERIAL_PELIGROSO</th>
                                                    <th>INDEMNIZACION</th>
                                                    <th>IMPORTE</th>
                                                    <th>ASIGNACION_DE_PRECIO</th>
                                                    <th>OBSERVACIONES</th>
                                                    <th>DIAS_PARA_RECUPERACION_DE_EVIDENCIAS</th>
                                                    <th>EDITAR_REGISTRO</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $rutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($ruta->id); ?></td>
                                                        <td><?php echo e($ruta->nombre); ?></td>
                                                        <td><?php echo e($ruta->clientesF->nombre); ?></td>
                                                        <td><?php echo e($ruta->lugar_exp); ?></td>
                                                        <td><?php echo e($ruta->origen); ?></td>
                                                        <td><?php echo e($ruta->remitente); ?></td>
                                                        <td><?php echo e($ruta->dom_remitente); ?></td>
                                                        <td><?php echo e($ruta->recoge); ?></td>
                                                        <td><?php echo e($ruta->valor_declarado); ?></td>
                                                        <td><?php echo e($ruta->destino); ?></td>
                                                        <td><?php echo e($ruta->destinatario); ?></td>
                                                        <td><?php echo e($ruta->dom_destinatario); ?></td>
                                                        <td><?php echo e($ruta->entrega); ?></td>
                                                        <td><?php echo e($ruta->fecha_entrega); ?></td>
                                                        <td><?php echo e($ruta->cantidad); ?></td>
                                                        <td><?php echo e($ruta->embalaje); ?></td>
                                                        <td><?php echo e($ruta->concepto); ?></td>
                                                        <td><?php echo e($ruta->material_peligroso); ?></td>
                                                        <td><?php echo e($ruta->indemnizacion); ?></td>
                                                        <td><?php echo e($ruta->importe); ?></td>
                                                        <td><?php echo e($ruta->nombre); ?></td>
                                                        <td><?php echo e($ruta->obs); ?></td>
                                                        <td><?php echo e($ruta->dias_re); ?></td>
                                                        <!--<td>
                                                            <form method="post" action="<?php echo e(url('/rutas/'.$ruta->id)); ?>">
                                                                <?php echo e(csrf_field()); ?>

                                                                <?php echo e(method_field('DELETE')); ?>

                                                                <button type="submit" onclick="return confirm('Eliminar');" class="btn btn-danger"><i class="far fa-trash-alt"></i> Eliminar</button>
                                                            </form>
                                                        </td>-->
                                                        <td>
                                                            <a href="<?php echo e(url('/rutas/'.$ruta->id.'/edit')); ?>" class="btn btn-primary"><i class="far fa-edit"></i> Editar</a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </table>
                                        </div>
                                        <?php echo e($rutas->render()); ?>

                                    </div><!-- End .accordion-body-wrapper -->
                                </div><!-- End .accordion-body -->
                            </div><!-- End .accordion-group -->
                            <div class="accordion-group panel">
                                <div class="accordion-header">
                                    <div class="accordion-title">Datos de Facturacion</div><!-- End .accourdion-title -->
                                    <a class="accordion-btn" data-toggle="collapse" data-parent="#accordion" href="#accordion-three"></a>
                                </div><!-- End .accordion-header -->

                                <div class="accordion-body collapse" id="accordion-three">
                                    <div class="accordion-body-wrapper">
                                        <table class="table table-responsive table-hover table-striped">
                                            <thead class="table-info">
                                            <tr>
                                                <th>ID</th>
                                                <th>RUTAS</th>
                                                <th>RAZON_SOCIAL_QUE_FACTURA</th>
                                                <th>ASIGNACION_DE_PRECIO</th>
                                                <th>CLAVE_DE_PRODUCTO_O_SERVICIO</th>
                                                <th>NUMERO_DE_IDENTIFICACION</th>
                                                <th>CANTIDAD</th>
                                                <th>CLAVE_DE_UNIDAD</th>
                                                <th>UNIDAD</th>
                                                <th>DESCRIPCION</th>
                                                <th>VALOR_UNITARIO</th>
                                                <th>IMPORTE</th>
                                                <th>TRASLADO_DE_IVA_(PORCENTAJE)</th>
                                                <th>TRASLADO_DE_ISR_(PORCENTAJE)</th>
                                                <th>RETENCION_DE_IVA_(PORCENTAJE)</th>
                                                <th>RETENCION_DE_ISR_(PORCENTAJE)</th>
                                                <th>EDITAR_REGISTRO</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $datosF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($dt->id); ?></td>
                                                    <td><?php echo e($dt->rutasF->nombre); ?></td>
                                                    <?php if($dt->facturador == 1): ?>
                                                        <td value="1" selected>RUBEN GUTIERREZ VELAZCO</td>
                                                    <?php else: ?>
                                                        <td value="2" selected>TRANSPORTES LOGIEXPRESS SA DE CV</td>
                                                    <?php endif; ?>
                                                    <td><?php echo e($dt->provedoresF->nombre); ?></td>
                                                    <td><?php echo e($dt->claveProdServ); ?></td>
                                                    <td><?php echo e($dt->noIdentificacion); ?></td>
                                                    <td><?php echo e($dt->cantidad); ?></td>
                                                    <td><?php echo e($dt->claveUnidad); ?></td>
                                                    <td><?php echo e($dt->unidad); ?></td>
                                                    <td><?php echo e($dt->descripcion); ?></td>
                                                    <td><?php echo e($dt->valorUnitario); ?></td>
                                                    <td><?php echo e($dt->importe); ?></td>
                                                    <td><?php echo e($dt->tIva); ?></td>
                                                    <td><?php echo e($dt->tIsr); ?></td>
                                                    <td><?php echo e($dt->rIva); ?></td>
                                                    <td><?php echo e($dt->rIsr); ?></td>
                                                    <!--<td>
                                                        <form method="post" action="<?php echo e(url('/datosFacturacions/'.$dt->id)); ?>">
                                                            <?php echo e(csrf_field()); ?>

                                                            <?php echo e(method_field('DELETE')); ?>

                                                            <button type="submit" onclick="return confirm('Eliminar');" class="btn btn-danger">Eliminar</button>
                                                        </form>
                                                    </td>-->
                                                    <td>
                                                        <a href="<?php echo e(url('/datosFacturacions/'.$dt->id.'/edit')); ?>" class="btn btn-primary">Editar</a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                        <?php echo e($datosF->render()); ?>

                                    </div><!-- End .accordion-body-wrapper -->
                                </div><!-- End .accordion-body -->
                            </div><!-- End .accordion-group -->
                            <div class="accordion-group panel">
                                <div class="accordion-header">
                                    <div class="accordion-title">Datos Cuentas por Pagar</div><!-- End .accourdion-title -->
                                    <a class="accordion-btn" data-toggle="collapse" data-parent="#accordion" href="#accordion-five"></a>
                                </div><!-- End .accordion-header -->

                                <div class="accordion-body collapse" id="accordion-five">
                                    <div class="accordion-body-wrapper">
                                        <table class="table table-responsive table-hover table-striped">
                                            <thead class="table-info">
                                            <tr>
                                                <th>ID</th>
                                                <th>RUTAS</th>
                                                <th>CONCEPTO</th>
                                                <th>ASIGNACION_DE_PRECIO</th>
                                                <th>CLAVE_DE_PRODUCTO_O_SERVICIO</th>
                                                <th>NUMERO_DE_IDENTIFICACION</th>
                                                <th>CANTIDAD</th>
                                                <th>CLAVE_DE_UNIDAD</th>
                                                <th>UNIDAD</th>
                                                <th>DESCRIPCION</th>
                                                <th>VALOR_UNITARIO</th>
                                                <th>IMPORTE</th>
                                                <th>TRASLADO_DE_IVA_(PORCENTAJE)</th>
                                                <th>TRASLADO_DE_ISR_(PORCENTAJE)</th>
                                                <th>RETENCION_DE_IVA_(PORCENTAJE)</th>
                                                <th>RETENCION_DE_ISR_(PORCENTAJE)</th>
                                                <th>EDITAR_REGISTRO</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $datosCxPListado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dCxP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($dCxP->id); ?></td>
                                                    <td><?php echo e($dCxP->rutaF->nombre); ?></td>
                                                    <td><?php echo e($dCxP->concepto); ?></td>
                                                    <td><?php echo e($dCxP->asignacionPrecioF->nombre); ?></td>
                                                    <td><?php echo e($dCxP->claveProdServ); ?></td>
                                                    <td><?php echo e($dCxP->noIdentificacion); ?></td>
                                                    <td><?php echo e($dCxP->cantidad); ?></td>
                                                    <td><?php echo e($dCxP->claveUnidad); ?></td>
                                                    <td><?php echo e($dCxP->unidad); ?></td>
                                                    <td><?php echo e($dCxP->descripcion); ?></td>
                                                    <td><?php echo e($dCxP->valorUnitario); ?></td>
                                                    <td><?php echo e($dCxP->importe); ?></td>
                                                    <td><?php echo e($dCxP->tivaCxP); ?></td>
                                                    <td><?php echo e($dCxP->tisrCxP); ?></td>
                                                    <td><?php echo e($dCxP->rivaCxP); ?></td>
                                                    <td><?php echo e($dCxP->risrCxP); ?></td>
                                                    <!--<td>
                                                        <form method="post" action="<?php echo e(url('/datosCporPagar/'.$dCxP->id)); ?>">
                                                            <?php echo e(csrf_field()); ?>

                                                            <?php echo e(method_field('DELETE')); ?>

                                                            <button id="eliminarCxP" type="submit" onclick="return confirm('Eliminar');" class="btn btn-danger">Eliminar</button>
                                                        </form>
                                                    </td>-->
                                                    <td>
                                                        <a id="editarCxP" href="<?php echo e(url('/datosCporPagar/'.$dCxP->id.'/edit')); ?>" class="btn btn-primary" title="En mantenimiento" data-toggle="tooltip">Editar</a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                        <?php echo e($datosF->render()); ?>

                                    </div><!-- End .accordion-body-wrapper -->
                                </div><!-- End .accordion-body -->
                            </div><!-- End .accordion-group -->
                            <div class="accordion-group panel">
                                <div class="accordion-header">
                                    <div class="accordion-title">Tarifas</div><!-- End .accourdion-title -->
                                    <a class="accordion-btn" data-toggle="collapse" data-parent="#accordion" href="#accordion-six"></a>
                                </div><!-- End .accordion-header -->

                                <div class="accordion-body collapse" id="accordion-six">
                                    <div class="accordion-body-wrapper">
                                        <p>Pellentesque malesuada sollicitudin fermentum. Nullam ultricesposuere congue. Turpis rhoncus. Nullam pretium eleifend neque, eget congue purus tincidunt id. Duis quam vitae condimentum.</p>
                                        <p>Sed pretium, elit eget fermentum mattis, tortor eros aliquam purus,  lacus mauris pellentesque odio, ut rhoncus erat risus sed.</p>
                                    </div><!-- End .accordion-body-wrapper -->
                                </div><!-- End .accordion-body -->
                            </div><!-- End .accordion-group -->
                        </div><!-- End .accordion -->

                    </div><!-- End .col-md-6 -->

                </div> <!-- row -->
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/ruta/rutas.blade.php ENDPATH**/ ?>