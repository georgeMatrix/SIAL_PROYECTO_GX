<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class=" card bg-dark">
            <div class="row">
                <div class="col-md-9 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class=" text-danger far fa-id-card"></i> NUEVO OPERADOR</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('operadores.index')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('operadores.store')); ?>" method="post" id="formOperador">
                    <?php echo e(csrf_field()); ?>

                    <?php if(empty($id->id)): ?>
                        <input type="hidden" value="1" name="id">
                    <?php else: ?>
                        <input type="hidden" value="<?php echo e($id->id+1); ?>" name="id">
                    <?php endif; ?>
                    <div class="form-group">
                        <h5 for="">Apellido paterno</h5>
                        <input maxlength="20" required type="text" name="apellido_paterno" id="apellido_paterno" class="form-control">
                    </div>

                    <div class="form-group">
                        <h5 for="">Apellido materno</h5>
                        <input maxlength="20" required type="text" name="apellido_materno" id="apellido_materno" class="form-control">
                    </div>

                    <div class="form-group">
                        <h5 for="">Nombres</h5>
                        <input maxlength="50" required type="text" name="nombres" id="nombres" class="form-control">
                    </div>

                    <div class="form-group">
                        <h5 for="">Nombre corto</h5>
                        <input maxlength="20" required type="text" name="nombre_corto" id="nombre_corto" class="form-control">
                    </div>

                    <div class="form-group">
                        <h5 for="">Numero de licencia</h5>
                        <input maxlength="20" required type="text" name="licencia" id="licencia" class="form-control">
                    </div>

                    <div class="form-group">
                        <h5 for="">Vigencia de licencia</h5>
                        <!-- <input type="text" class="form-control" id="datapicker">-->
                        <input type="text" required readonly name="vigencia_licencia" id="vigencia_licencia" class="form-control">
                    </div>

                    <div class="form-group">
                        <h5 for="">Vigencia de examen medico</h5>
                        <input type="text" required readonly name="vigencia_medico" id="vigencia_medico" class="form-control">
                    </div>

                    <div class="form-group">
                        <h5 for="">Observaciones</h5>
                        <input maxlength="100" type="text" name="obs" id="obs" class="form-control">
                    </div>

                    <button id="guardarOperador" type="submit" class="btn btn-info"><i class="far fa-save"></i> Guardar</button>
                </form>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        jQuery.fn.datepicker.dates['es'] = {
            days: ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
            daysShort: ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"],
            daysMin: ["Do", "Lu", "Ma", "Mi", "Ju", "Vi", "Sá"],
            months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
            monthsShort: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
            today: "Hoy",
            clear: "Borrar",
            format: "dd/mm/yyyy",
            titleFormat: "MM yyyy", /* Leverages same syntax as 'format' */
            weekStart: 0
        };

        jQuery('#vigencia_licencia').datepicker({
                format: "yyyy/mm/dd",
                language: "es",
                autoclose: true
            });
        jQuery('#vigencia_medico').datepicker({
                format: "yyyy/mm/dd",
                language: "es",
                autoclose: true
            });
        $(document).ready(function() {
            $("#formOperador").on('submit', function(){
                $("#guardarOperador").prop("disabled", true);
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/GEORGE/sail/resources/views/operador/operadorCreate.blade.php ENDPATH**/ ?>