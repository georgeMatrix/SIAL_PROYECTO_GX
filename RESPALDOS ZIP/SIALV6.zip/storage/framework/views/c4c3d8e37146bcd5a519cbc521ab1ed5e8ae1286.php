<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-6 card-title">
                    <h3 class="text-center text-white"><i class="text-danger mt-3 fa fa-id-card fa-md"></i> LISTADO OPERADORES</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('operadores.create')); ?>" class="mt-3 btn btn-info float-right"><i class="fa fa-id-card fa-lg"></i> Nuevo Operador</a>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(url('/home')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                <table class="table table-hover table-sm table-striped">
                    <thead class="table-info">
                    <tr>
                        <th>ID</th>
                        <th>APELLIDO_PATERNO</th>
                        <th>APELLIDO_MATERNO</th>
                        <th>NOMBRES</th>
                        <th>NOMBRE_CORTO</th>
                        <th>NUMERO_DE_LICENCIA</th>
                        <th>VIGENCIA_LICENCIA</th>
                        <th>VIGENCIA_DE_EXAMEN_MEDICO</th>
                        <th>TELEFONO_DE_CASA</th>
                        <th>PERSONA_DE_CONTACTO</th>
                        <th>CELULAR</th>
                        <th>IMSS</th>
                        <th>RFC</th>
                        <th>OBSERVACIONES</th>
                        <th>EDITAR_REGISTRO</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $operadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($operador->id); ?></td>
                            <td><?php echo e($operador->apellido_paterno); ?></td>
                            <td><?php echo e($operador->apellido_materno); ?></td>
                            <td><?php echo e($operador->nombres); ?></td>
                            <td><?php echo e($operador->nombre_corto); ?></td>
                            <td><?php echo e($operador->licencia); ?></td>
                            <td><?php echo e($operador->vigencia_licencia); ?></td>
                            <td><?php echo e($operador->vigencia_medico); ?></td>
                            <td><?php echo e($operador->telefonoCasa); ?></td>
                            <td><?php echo e($operador->personaContacto); ?></td>
                            <td><?php echo e($operador->celular); ?></td>
                            <td><?php echo e($operador->imss); ?></td>
                            <td><?php echo e($operador->rfc); ?></td>
                            <td><?php echo e($operador->obs); ?></td>
                            <!--<td>
                                <form method="post" action="<?php echo e(url('/operadores/'.$operador->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" onclick="return confirm('Eliminar');" class="btn btn-danger"><i class="far fa-trash-alt"></i> Eliminar</button>
                                </form>
                            </td>-->
                            <td>
                                <a href="<?php echo e(url('/operadores/'.$operador->id.'/edit')); ?>" class="btn btn-primary"><i class="far fa-edit"></i> Editar</a>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                </div>
                <?php echo e($operadores->render()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/operador/operadores.blade.php ENDPATH**/ ?>