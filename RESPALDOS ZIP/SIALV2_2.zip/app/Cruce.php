<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cruce extends Model
{
    //
}
