<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php $__currentLoopData = $cartaPorte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h5 class="text-danger">lugar_exp: </h5><?php echo e($cP->rutaCartaP->lugar_exp); ?>

                <h5 class="text-danger">referencia: </h5><?php echo e($cP->referencia); ?>

                <h5 class="text-danger">remitente: </h5><?php echo e($cP->rutaCartaP->remitente); ?>

                <h5 class="text-danger">destinatario: </h5><?php echo e($cP->rutaCartaP->destinatario); ?>

                <h5 class="text-danger">dom_destinatario: </h5><?php echo e($cP->rutaCartaP->dom_destinatario); ?>

                <h5 class="text-danger">fecha de entrega: </h5><?php echo e($cP->fechaDeEntrega); ?>

                <h5 class="text-danger">fecha de entrega: </h5><?php echo e($cP->fechaDeEntrega); ?>

                <h5 class="text-danger">importe: </h5><?php echo e($cP->rutaCartaP->importe); ?>

                <h5 class="text-danger">cantidad: </h5><?php echo e($cP->rutaCartaP->cantidad); ?>

                <h5 class="text-danger">embalaje: </h5><?php echo e($cP->rutaCartaP->embalaje); ?>

                <h5 class="text-danger">concepto: </h5><?php echo e($cP->rutaCartaP->concepto); ?>

                <h5 class="text-danger">unidades: provedor: nombre </h5><?php echo e($cP->unidadesF->provedores->nombre); ?>

                <h5 class="text-danger">carta porte:operador </h5><?php echo e($cP->operadorF->nombre_corto); ?>

                <h5 class="text-danger">carta porte:unidad consulta</h5><?php echo e($cP->unidadesF->economico); ?>

                <h5 class="text-danger">carta porte:unidad unidades placas</h5><?php echo e($cP->unidadesF->placas); ?>

                <h5 class="text-danger">carta porte:unidad economico</h5><?php echo e($cP->remolquesF->economico); ?>

                <h5 class="text-danger">carta porte:remolque placas</h5><?php echo e($cP->remolquesF->placas); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/cartaPorte/cartaPortePDF.blade.php ENDPATH**/ ?>