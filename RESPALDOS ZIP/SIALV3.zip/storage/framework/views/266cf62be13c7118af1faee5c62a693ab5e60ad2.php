<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-6 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-user-circle fa-md text-danger"></i> LISTADO USUARIOS</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('usuarios.create')); ?>" class="mt-3 btn btn-info float-right"><i class="fas fa-user"></i> Nuevo Usuario</a>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(url('/home')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-hover table-sm table-striped">
                    <thead class="table-primary">
                    <tr>
                        <th>ID</th>
                        <th>APELLIDO_PATERNO</th>
                        <th>APELLIDO_MATERNO</th>
                        <th>NOMBRE</th>
                        <th>PASSWORD</th>
                        <th>NOMBRE_CORTO</th>
                        <th>CARGO_DEL_USUARIO</th>
                        <th>AREA</th>
                        <th>CATALOGOS</th>
                        <th>RUTAS</th>
                        <th>CARTA_PORTE</th>
                        <th>FACTURACION</th>
                        <th>MODULO_05</th>
                        <th>MODULO_06</th>
                        <th>MODULO_07</th>
                        <th>MODULO_08</th>
                        <th>MODULO_09</th>
                        <th>MODULO_10</th>
                        <th>ELIMINAR_REGISTRO</th>
                        <th>ACTUALIZAR_REGISTRO</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($usuario->id); ?></td>
                            <td><?php echo e($usuario->apellidoPaterno); ?></td>
                            <td><?php echo e($usuario->apellidoMaterno); ?></td>
                            <td><?php echo e($usuario->nombre); ?></td>
                            <td><?php echo e($usuario->password); ?></td>
                            <td><?php echo e($usuario->nombreCorto); ?></td>
                            <td><?php echo e($usuario->cargo); ?></td>
                            <td><?php echo e($usuario->area); ?></td>
                            <td><?php echo e($usuario->modulo01); ?></td>
                            <td><?php echo e($usuario->modulo02); ?></td>
                            <td><?php echo e($usuario->modulo03); ?></td>
                            <td><?php echo e($usuario->modulo04); ?></td>
                            <td><?php echo e($usuario->modulo05); ?></td>
                            <td><?php echo e($usuario->modulo06); ?></td>
                            <td><?php echo e($usuario->modulo07); ?></td>
                            <td><?php echo e($usuario->modulo08); ?></td>
                            <td><?php echo e($usuario->modulo09); ?></td>
                            <td><?php echo e($usuario->modulo10); ?></td>
                            <td>
                                <form method="post" action="<?php echo e(url('/usuarios/'.$usuario->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" onclick="return confirm('Eliminar');" class="btn btn-danger"><i class="far fa-trash-alt"></i> Eliminar</button>
                                </form>
                            </td>
                            <td>
                                <a href="<?php echo e(url('/usuarios/'.$usuario->id.'/edit')); ?>" class="btn btn-primary"><i class="far fa-edit"></i> Editar</a>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                </div>
                <?php echo e($usuarios->render()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/usuario/usuarios.blade.php ENDPATH**/ ?>