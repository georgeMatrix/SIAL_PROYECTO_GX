<?php

namespace App\Http\Controllers;

use App\TarifasRuta;
use Illuminate\Http\Request;

class TarifasRutaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TarifasRuta  $tarifasRuta
     * @return \Illuminate\Http\Response
     */
    public function show(TarifasRuta $tarifasRuta)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TarifasRuta  $tarifasRuta
     * @return \Illuminate\Http\Response
     */
    public function edit(TarifasRuta $tarifasRuta)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TarifasRuta  $tarifasRuta
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TarifasRuta $tarifasRuta)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TarifasRuta  $tarifasRuta
     * @return \Illuminate\Http\Response
     */
    public function destroy(TarifasRuta $tarifasRuta)
    {
        //
    }
}
