@extends('layouts.app')
@section('content')
    llegando
    @endsection