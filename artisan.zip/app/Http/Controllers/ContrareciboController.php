<?php

namespace App\Http\Controllers;

use App\Contrarecibo;
use Illuminate\Http\Request;

class ContrareciboController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Contrarecibo  $contrarecibo
     * @return \Illuminate\Http\Response
     */
    public function show(Contrarecibo $contrarecibo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Contrarecibo  $contrarecibo
     * @return \Illuminate\Http\Response
     */
    public function edit(Contrarecibo $contrarecibo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Contrarecibo  $contrarecibo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Contrarecibo $contrarecibo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Contrarecibo  $contrarecibo
     * @return \Illuminate\Http\Response
     */
    public function destroy(Contrarecibo $contrarecibo)
    {
        //
    }
}
