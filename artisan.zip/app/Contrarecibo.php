<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contrarecibo extends Model
{
    protected $fillable = ['contrarecibo'];
}
