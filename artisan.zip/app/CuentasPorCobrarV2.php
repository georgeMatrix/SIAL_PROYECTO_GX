<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CuentasPorCobrarV2 extends Model
{
    //
}
