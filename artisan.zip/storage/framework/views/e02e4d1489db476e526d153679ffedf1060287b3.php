<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-4 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-file-alt fa-lg text-danger"></i> LISTADO CARTA PORTE</h3>
                </div>
                <div class="col-md-2">
                    <a href="#" class="mt-3 btn btn-info float-right"><i class="fas fa-folder-open"></i> Evidencias</a>
                </div>
                <div class="col-md-2">
                <button type="button" class="mt-3 btn btn-info float-right" <?php if(count($release) == 0): ?> disabled <?php endif; ?> data-toggle="modal" data-target="#exampleModal"><i class="fas fa-file-signature"></i>
                    Release
                </button>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo e(route('cartaPorte.create')); ?>" class="mt-3 btn btn-info float-right"><i class="fa fa-file-alt"></i> Nueva</a>
                </div>
                <div class="col-md-2">
                    <a href="<?php echo e(url('/home')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive content-loader">
                    <table class="table table-hover table-sm table-striped">
                        <thead class="table-info">
                        <tr>
                            <th>ID</th>
                            <th>TIPO</th>
                            <th>FECHA</th>
                            <th>RUTA</th>
                            <th>UNIDAD</th>
                            <th>REMOLQUE</th>
                            <th>OPERADOR</th>
                            <th>REFERENCIA</th>
                            <th>FECHA_EMBARQUE</th>
                            <th>FECHA_ENTREGA</th>
                            <th>STATUS</th>
                            <th>ULTIMO_STATUS</th>
                            <th>FECHA_STATUS</th>
                            <th>EDITAR_REGISTRO</th>
                            <th>PDF</th>
                        </tr>
                        </thead>
                        <tbody>

                        <?php $__currentLoopData = $cartaPorte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php $__currentLoopData = $nacional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cP->id == $n->cartaPorte): ?>
                                        <td><?php echo e($n->id); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $importacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cP->id == $i->cartaPorte): ?>
                                        <td><?php echo e($i->id); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $exportacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cP->id == $e->cartaPorte): ?>
                                        <td><?php echo e($e->id); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $cruce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cP->id == $c->cartaPorte): ?>
                                        <td><?php echo e($c->id); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <?php if($cP->tipo == 'N'): ?>
                                    <td><?php echo e($tipos[0]); ?></td>
                                <?php elseif($cP->tipo == 'I'): ?>
                                    <td><?php echo e($tipos[1]); ?></td>
                                <?php elseif($cP->tipo == 'E'): ?>
                                    <td><?php echo e($tipos[2]); ?></td>
                                <?php elseif($cP->tipo == 'C'): ?>
                                    <td><?php echo e($tipos[3]); ?></td>
                                <?php endif; ?>
                                <td><?php echo e($cP->fecha); ?></td>
                                <td><?php echo e($cP->rutaCartaP->nombre); ?></td>
                                <td><?php echo e($cP->unidadesF->economico); ?></td>
                                <td><?php echo e($cP->remolquesF->economico); ?></td>
                                <td><?php echo e($cP->operadorF->nombre_corto); ?></td>
                                <td><?php echo e($cP->referencia); ?></td>
                                <td><?php echo e($cP->fechaDeEmbarque); ?></td>
                                <td><?php echo e($cP->fechaDeEntrega); ?></td>
                                <td><?php echo e($cP->status); ?></td>
                                <?php for($i=1; $i<=$cP->id; $i++): ?>
                                    <?php if($ultimo[$i]->ref == $cP->id): ?>
                                    <td><?php echo e($ultimo[$i]->status); ?></td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                                <?php for($i=1; $i<=$cP->id; $i++): ?>
                                    <?php if($ultimo[$i]->ref == $cP->id): ?>
                                        <td><?php echo e($ultimo[$i]->fecha); ?></td>
                                    <?php endif; ?>
                                <?php endfor; ?>
                                <!--<td>
                                    <form method="post" action="<?php echo e(url('/cartaPorte/'.$cP->id)); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" onclick="return confirm('Eliminar');" class="btn btn-danger"><i class="far fa-trash-alt"></i> Eliminar</button>
                                    </form>
                                </td>-->
                                <td>
                                    <a href="<?php echo e(url('/cartaPorte/'.$cP->id.'/edit')); ?>" class="btn btn-primary"><i class="far fa-edit"></i> Editar</a>
                                </td>
                                <td><a href="<?php echo e(url('pdf/'.$cP->id)); ?>" class="btn btn-secondary" >PDF</a></td>
                            </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <?php echo e($cartaPorte->render()); ?>

                <?php echo $__env->make('include.modalCartaPorte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/cartaPorte/cartasPorte.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/cartaPorte/cartasPorte.blade.php ENDPATH**/ ?>