<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-6 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-map-marked fa-lg text-danger"></i> LISTADO CLIENTES</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('clientes.create')); ?>" class="mt-3 btn btn-info float-right"><i class="fas fa-user"></i> Nuevo Cliente</a>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(url('/home')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive content-loader">
                    <table class="table table-hover table-sm table-striped">
                    <thead class="table-info">
                    <tr>
                        <th>ID</th>
                        <th width="100%">NOMBRE_CLIENTE</th>
                        <th>RAZON_SOCIAL</th>
                        <th>RFC</th>
                        <th>REGIMEN</th>
                        <th>CALLE</th>
                        <th>NUMERO</th>
                        <th>NUMERO_INTERIOR</th>
                        <th>COLONIA</th>
                        <th>CIUDAD_O_MUNICIPIO</th>
                        <th>CODIGO_POSTAL</th>
                        <th>ESTADO</th>
                        <th>PRIMER_CONTACTO</th>
                        <th>TELEFONO</th>
                        <th>MAIL</th>
                        <th>SEGUNDO_CONTACTO</th>
                        <th>TELEFONO</th>
                        <th>MAIL</th>
                        <th>DIA_DE_REVISION</th>
                        <th>DIA_DE_CREDITO</th>
                        <th>EDITAR_REGISTRO</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cliente->id); ?></td>
                            <td><?php echo e($cliente->nombre); ?></td>
                            <td><?php echo e($cliente->razonSocial); ?></td>
                            <td><?php echo e($cliente->rfc); ?></td>
                            <td><?php echo e($cliente->regimen); ?></td>
                            <td><?php echo e($cliente->calle); ?></td>
                            <td><?php echo e($cliente->numero); ?></td>
                            <td><?php echo e($cliente->interior); ?></td>
                            <td><?php echo e($cliente->colonia); ?></td>
                            <td><?php echo e($cliente->ciudad); ?></td>
                            <td><?php echo e($cliente->cp); ?></td>
                            <td><?php echo e($cliente->estado); ?></td>
                            <td><?php echo e($cliente->contacto1); ?></td>
                            <td><?php echo e($cliente->tel1); ?></td>
                            <td><?php echo e($cliente->mail1); ?></td>
                            <td><?php echo e($cliente->contacto2); ?></td>
                            <td><?php echo e($cliente->tel2); ?></td>
                            <td><?php echo e($cliente->mail2); ?></td>
                            <?php for($j=1; $j<6; $j++): ?>
                                <?php if($cliente->dia_revision == $j): ?>
                                    <td><?php echo e($dias[$j]); ?></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <td><?php echo e($cliente->dia_credito); ?></td>
                            <!--<td>
                                <form method="post" action="<?php echo e(url('/clientes/'.$cliente->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" onclick="return confirm('Eliminar');" class="btn btn-danger"><i class="far fa-trash-alt"></i> Eliminar</button>
                                </form>
                            </td>-->
                            <td>
                                <a href="<?php echo e(url('/clientes/'.$cliente->id.'/edit')); ?>" class="btn btn-primary"><i class="far fa-edit"></i> Editar</a>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                </div>
                <?php echo e($clientes->render()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\LARAVEL\SIAL V2\sail\resources\views/cliente/clientes.blade.php ENDPATH**/ ?>