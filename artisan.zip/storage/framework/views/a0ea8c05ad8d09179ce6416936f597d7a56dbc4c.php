<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-9 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class="fa fa-truck fa-md text-danger"></i> NUEVA UNIDAD</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('unidades.index')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(route('unidades.store')); ?>" method="post" id="formUnidad">
                    <?php echo e(csrf_field()); ?>

                    <?php if(empty($id->id)): ?>
                        <input type="hidden" value="1" name="id">
                    <?php else: ?>
                        <input type="hidden" value="<?php echo e($id->id+1); ?>" name="id">
                    <?php endif; ?>

                    <div class="form-group">
                        <h5 for="">Proveedor</h5>
                        <select name="provedor" required id="provedor" class="form-control">
                            <?php $__currentLoopData = $provedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($provedor->id); ?>"><?php echo e($provedor->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <h5 for="">Nombre de la unidad</h5>
                        <input maxlength="70" required type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>">
                    </div>

                    <div class="form-group">
                        <h5 for="">Economico</h5>
                        <input maxlength="10" required type="text" name="economico" id="economico" class="form-control" value="<?php echo e(old('economico')); ?>">
                    </div>

                    <div class="form-group">
                        <h5 for="">Tipo de unidad</h5>
                        <select name="tipo" id="tipo" class="form-control">
                            <option value="1">TRACTOCAMION</option>
                            <option value="2">REMOLQUE</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <h5 for="">Marca</h5>
                        <input maxlength="20" required type="text" name="marca" id="marca" class="form-control" value="<?php echo e(old('economico')); ?>">
                    </div>

                    <div class="form-group">
                        <h5 for="">Modelo</h5>
                        <input maxlength="20" required type="text" name="modelo" id="modelo" class="form-control" value="<?php echo e(old('modelo')); ?>">
                    </div>

                    <div class="form-group">
                        <h5 for="">Placas</h5>
                        <input maxlength="20" required type="text" name="placas" id="placas" class="form-control" value="<?php echo e(old('placas')); ?>">
                        <div class="invalid-feedback">
                            El campo placas es requerido
                        </div>
                    </div>

                    <div class="form-group">
                        <h5 for="">Numero de serie de chasis</h5>
                        <input maxlength="30" required type="text" name="serie" id="serie" class="form-control" value="<?php echo e(old('serie')); ?>">
                    </div>

                    <div class="form-group">
                        <h5 for="">Numero de serie de motor</h5>
                        <input maxlength="30" required type="text" name="motor" id="motor" class="form-control" value="<?php echo e(old('motor')); ?>">
                    </div>

                    <div class="form-group">
                        <h5 for="">Vencimiento de poliza de seguro</h5>
                        <input type="text" required readonly name="seguro" id="seguro" class="form-control <?php echo e($errors->has('seguro')?'is-invalid':''); ?>" value="<?php echo e(old('seguro')); ?>" value="<?php echo e(old('seguro')); ?>">
                        <?php echo $errors->first('seguro','<div class="invalid-feedback">:message</div>'); ?>

                    </div>

                    <div class="form-group">
                        <h5 for="">Vencimiento de Verificacion</h5>
                        <input type="text" required readonly name="verificacion" id="verificacion" class="form-control <?php echo e($errors->has('verificacion')?'is-invalid':''); ?>" value="<?php echo e(old('verificacion')); ?>" value="<?php echo e(old('verificacion')); ?>">
                        <?php echo $errors->first('verificacion','<div class="invalid-feedback">:message</div>'); ?>

                    </div>

                    <div class="form-group">
                        <h5 for="">Vencimiento de fisico mecania</h5>
                        <input type="text" required readonly name="fm" id="fm" class="form-control <?php echo e($errors->has('fm')?'is-invalid':''); ?>" value="<?php echo e(old('fm')); ?>">
                        <?php echo $errors->first('fm','<div class="invalid-feedback">:message</div>'); ?>

                    </div>

                    <div class="form-group">
                        <h5 for="">Observaciones</h5>
                        <input maxlength="100" type="text" name="obs" id="obs" class="form-control" value="<?php echo e(old('obs')); ?>">
                    </div>

                    <button id="guardarCreate" type="submit" class="btn btn-info">Guardar</button>
                </form>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/unidad/unidadCreate.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMACION\LARAVEL\SIAL V2\sail\resources\views/unidad/unidadCreate.blade.php ENDPATH**/ ?>