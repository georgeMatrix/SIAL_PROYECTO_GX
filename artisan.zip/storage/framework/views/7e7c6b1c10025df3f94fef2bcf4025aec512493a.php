<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-6 card-title">
                    <h3 class="text-center text-white"><i class="text-danger mt-3 fa fa-id-card fa-md"></i> LISTADO CUENTAS POR COBRAR</h3>
                </div>
                <div class="col-md-6">
                    <a href="<?php echo e(url('/home')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                    <button disabled class="mt-3 mr-3 btn btn-info float-right" id="preV" onclick="generarPrevisualizacionFactura()" data-toggle="modal" data-target="#modalPrevisualizacionFacturar"> Previsualizacion</button>
                    <button disabled class="mt-3 mr-3 btn btn-info float-right" id="facturar" data-toggle="modal" data-target="#modalFacturar" onclick="inputCheckFacturar()"> Facturar</button>
                        <a href="#" id="XMLFactura" download="XMLFactura" class="btn btn-info mt-3 mr-3 float-right">XML</a>
                    
                    
                    
                </div>

            </div>
            <div class="row">

            </div>
        </div>
        <div class="col-md-12">
            <form action="#" method="post" id="formCuentasPorPagar">
                <input type="hidden" name="tokenCuentasPorPagar" id="tokenCuentasPorPagar" value="<?php echo e(csrf_token()); ?>">
                <div class="row">
                    <h5>Facturador</h5>
                    <select name="facturadorCuentasPorPagar" id="facturadorCuentasPorPagar" class="form-control">
                        <option value="" selected>Seleccione una opcion</option>
                        <option value="1">RUBEN GUTIERREZ VELAZCO</option>
                        <option value="2">TRANSPORTES LOGIEXPRESS SA DE CV</option>
                    </select>
                </div>
                <div class="row">
                    <h5>Cliente</h5>
                    <select name="clienteCuentasPorPagar" id="clienteCuentasPorPagar" class="form-control">
                        <option value="" selected>Seleccione una opcion</option>
                        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="row">
                    <button class="btn btn-success mt-2" id="consultar" type="submit">Consultar</button>
                </div>
            </form>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive content-loader">
                    <table class="table table-hover table-sm table-striped">
                        <thead>
                            <tr>
                                <th>SELECT</th>
                                <th>TIPO</th>
                                <th>CARTA_PORTE</th>
                                <th>FACTURADOR</th>
                                <th>CLIENTE</th>
                                <th>NOMBRE_RUTA</th>
                                <th>UNIDAD</th>
                                <th>REMOLQUE</th>
                                <th>OPERADOR</th>
                                <th>CLAVE_PRODUCTO_O_SERVICIO</th>
                                <th>NO._IDENTIFICACION</th>
                                <th>CANTIDAD</th>
                                <th>CLAVE_UNIDAD</th>
                                <th>UNIDAD</th>
                                <th>DESCRIPCION</th>
                                <th>VALOR_UNITARIO</th>
                                <th>IMPORTE</th>
                                <th>IVA_TRASLADADO</th>
                                <th>IVA_RETENIDO</th>
                                <th>TOTAL</th>
                            </tr>
                        </thead>
                        <tbody id="tablaCuentasPorPagar">
                        </tbody>
                        <!--<form action="<?php echo e(route('cuentasPorCobrarV2.store')); ?>" method="post" id="cuentasPorCobrarForm">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
                                <tbody id="tablaCuentasPorPagar">
                                </tbody>
                            <button type="submit" class="btn btn-info">Enviar</button>
                        </form>-->

                    </table>
                </div>
            </div>
        </div>
    </div>
    <div id="loading-screen" style="display:none">
        <img src="<?php echo e(asset('loader/img/spinning-circles.svg')); ?>">
    </div>
    <?php echo $__env->make('include.modalFacturar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.modalPrevisualizacionFactura', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/cuentasPorCobrar/cuentasPorCobrar.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMACION\LARAVEL\SIAL V2\sail\resources\views/cuentasPorCobrar/cuentasPorCobrarV2.blade.php ENDPATH**/ ?>