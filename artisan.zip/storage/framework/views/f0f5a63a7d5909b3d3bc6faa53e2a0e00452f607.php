<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card bg-dark">
            <div class="row">
                <div class="col-md-9 card-title">
                    <h3 style="font-size: 20pt;" class="mt-3 text-center text-white"><i class=" text-danger far fa-id-card"></i> ACTUALIZACION OPERADOR</h3>
                </div>
                <div class="col-md-3">
                    <a href="<?php echo e(route('operadores.index')); ?>" class="mt-3 mr-3 btn btn-info float-right"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(url('/operadores/'.$operador->id)); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PATCH')); ?>

                    <h5 for="">Apellido paterno</h5>
                    <input maxlength="20" required type="text" name="apellido_paterno" id="apellido_paterno" class="form-control" value="<?php echo e($operador->apellido_paterno); ?>">
                    <h5 for="">Apellido materno</h5>
                    <input maxlength="20" required type="text" name="apellido_materno" id="apellido_materno" class="form-control"  value="<?php echo e($operador->apellido_materno); ?>">
                    <h5 for="">Nombres</h5>
                    <input maxlength="50" required type="text" name="nombres" id="nombres" class="form-control"  value="<?php echo e($operador->nombres); ?>">
                    <h5 for="">Nombre corto</h5>
                    <input maxlength="20" required type="text" name="nombre_corto" id="nombre_corto" class="form-control"  value="<?php echo e($operador->nombre_corto); ?>">
                    <h5 for="">Numero de licencia</h5>
                    <input maxlength="20" required type="text" name="licencia" id="licencia" class="form-control"  value="<?php echo e($operador->licencia); ?>">
                    <h5 for="">Vigencia de licencia</h5>
                    <input type="text" readonly required name="vigencia_licencia" id="vigencia_licencia" class="form-control"  value="<?php echo e($operador->vigencia_licencia); ?>">
                    <h5 for="">Vigencia de examen medico</h5>
                    <input type="text" readonly required name="vigencia_medico" id="vigencia_medico" class="form-control"  value="<?php echo e($operador->vigencia_medico); ?>">
                    <h5 for="">Telefono de Casa</h5>
                    <input type="number" required maxlength="20" name="telefonoCasa" id="telefonoCasa" class="form-control" value="<?php echo e($operador->telefonoCasa); ?>">
                    <h5 for="">Persona de Contacto</h5>
                    <input type="text" maxlength="50" required name="personaContacto" id="personaContacto" class="form-control" value="<?php echo e($operador->personaContacto); ?>">
                    <h5 for="">Celular</h5>
                    <input type="number" maxlength="20" required name="celular" id="celular" class="form-control" value="<?php echo e($operador->celular); ?>">
                    <h5 for="">IMSS</h5>
                    <input type="text" maxlength="13" required name="imss" id="imss" class="form-control" value="<?php echo e($operador->imss); ?>">
                    <h5 for="">RFC</h5>
                    <input type="text" maxlength="13" required name="rfc" id="rfc" class="form-control" value="<?php echo e($operador->rfc); ?>">
                    <h5 for="">Observaciones</h5>
                    <input maxlength="100" required type="text" name="obs" id="obs" class="form-control"  value="<?php echo e($operador->obs); ?>">
                    <br>
                    <button type="submit" class="btn btn-info"><i class="far fa-edit"></i> Actualizar</button>
                </form>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/operador/operadorEdit.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMACION\LARAVEL\SIAL V2\sail\resources\views/operador/operadorEdit.blade.php ENDPATH**/ ?>