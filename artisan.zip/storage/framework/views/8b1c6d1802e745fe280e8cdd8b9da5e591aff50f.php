<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('include.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-12 text-center">
                <img height="700px" src="<?php echo e(asset('img/noAutorizado.png')); ?>" alt="">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PROGRAMACION\LARAVEL\SIAL V2\sail\resources\views/paginaError/paginaNoAutorizada.blade.php ENDPATH**/ ?>